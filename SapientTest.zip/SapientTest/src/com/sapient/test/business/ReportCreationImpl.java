package com.sapient.test.business;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sapient.test.bean.Transaction;

public class ReportCreationImpl implements ReportCreation {

	@Override
	public void createReport(List<Transaction> processesTxnList, String outFilePath) {
		Map<Transaction,Long> processingFeeM = new HashMap<>();
		for(Transaction tx : processesTxnList) {
			if(processingFeeM.containsKey(tx)) {
				processingFeeM.put(tx, processingFeeM.get(tx)+tx.getProcessingFee());
			}else {
				processingFeeM.put(tx, tx.getProcessingFee());
			}
		}
		
		Map<Transaction,Long> sortedMap = new TreeMap<Transaction,Long>(new Transaction.TransactionComparator());
		sortedMap.putAll(processingFeeM);
		
		
		Workbook workbook = new XSSFWorkbook();
		 
        Sheet reportSheet = workbook.createSheet("TransactionSummaryReport");
        int rowIndex = 0;
        Row row = reportSheet.createRow(rowIndex++);
        int cellIndex = 0;
        row.createCell(cellIndex++).setCellValue("ClientId");

        row.createCell(cellIndex++).setCellValue("Transaction Type");

        row.createCell(cellIndex++).setCellValue("Transaction Date");

        row.createCell(cellIndex++).setCellValue("Priority");
        
        row.createCell(cellIndex++).setCellValue("Processing Fee");
        
        CellStyle cellStyle = workbook.createCellStyle();
	    CreationHelper createHelper = workbook.getCreationHelper();
	    short dateFormat = createHelper.createDataFormat().getFormat("dd-MM-yy");
	    cellStyle.setDataFormat(dateFormat);
        
		for(Map.Entry<Transaction,Long> entry: sortedMap.entrySet()) {
			System.out.println(entry.getKey().getClientId() + " : " + entry.getKey().getTrxnType() 
					+ " : " + entry.getKey().getTrxnDate() + " : " + entry.getKey().isPriority() + ": processing Fee : " + entry.getValue());
 
            row = reportSheet.createRow(rowIndex++);
            cellIndex = 0;
            row.createCell(cellIndex++).setCellValue(entry.getKey().getClientId());
 
            row.createCell(cellIndex++).setCellValue(entry.getKey().getTrxnType());
            
            Cell cell = row.createCell(cellIndex++);
            cell.setCellValue(entry.getKey().getTrxnDate());
            cell.setCellStyle(cellStyle);
            
            row.createCell(cellIndex++).setCellValue(entry.getKey().isPriority() ? "Y" : "N");
            
            row.createCell(cellIndex++).setCellValue(entry.getValue());
 
        }
 
        try {
            FileOutputStream fos = new FileOutputStream(outFilePath);
            workbook.write(fos);
            fos.close();
 
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


	}

}
