package com.sapient.test.business;

import java.util.List;

import com.sapient.test.bean.Transaction;

public interface ReportCreation {
	
	public void createReport(List<Transaction> processesTxnList , String outFilePath);

}
