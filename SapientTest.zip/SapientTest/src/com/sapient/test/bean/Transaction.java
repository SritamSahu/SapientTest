package com.sapient.test.bean;

import java.util.Comparator;
import java.util.Date;

public class Transaction {
	
	private String extTransId;
	private String clientId;
	private String securityId;
	private String trxnType;
	private Date trxnDate;
	private double mktValue;
	private boolean priority;
	private long processingFee;
	private boolean isIntra;
	
	
	public Transaction() {
		
	}
	
	public Transaction(String extTransId, String clientId, String securityId, String trxnType, Date trxnDate,
			double mktValue, boolean priority) {
		this.extTransId = extTransId;
		this.clientId = clientId;
		this.securityId = securityId;
		this.trxnType = trxnType;
		this.trxnDate = trxnDate;
		this.mktValue = mktValue;
		this.priority = priority;
	}

	public String getExtTransId() {
		return extTransId;
	}

	public void setExtTransId(String extTransId) {
		this.extTransId = extTransId;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}

	public String getSecurityId() {
		return securityId;
	}

	public void setSecurityId(String securityId) {
		this.securityId = securityId;
	}

	public String getTrxnType() {
		return trxnType;
	}

	public void setTrxnType(String trxnType) {
		this.trxnType = trxnType;
	}

	public Date getTrxnDate() {
		return trxnDate;
	}

	public void setTrxnDate(Date trxnDate) {
		this.trxnDate = trxnDate;
	}

	public double getMktValue() {
		return mktValue;
	}

	public void setMktValue(double mktValue) {
		this.mktValue = mktValue;
	}

	public boolean isPriority() {
		return priority;
	}

	public void setPriority(boolean priority) {
		this.priority = priority;
	}
	
	public long getProcessingFee() {
		return processingFee;
	}

	public void setProcessingFee(long processingFee) {
		this.processingFee = processingFee;
	}
	
	public boolean isIntra() {
		return priority;
	}

	public void setIntra(boolean priority) {
		this.priority = priority;
	}

	@Override
	public String toString() {
		return "Transaction [extTransId=" + extTransId + ", clientId=" + clientId + ", securityId=" + securityId
				+ ", trxnType=" + trxnType + ", trxnDate=" + trxnDate + ", mktValue=" + mktValue + ", priority="
				+ priority + ", processingFee=" + processingFee + ", isIntra=" + isIntra +"] \n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((clientId == null) ? 0 : clientId.hashCode());
		result = prime * result + (priority ? 1231 : 1237);
		result = prime * result + ((trxnDate == null) ? 0 : trxnDate.hashCode());
		result = prime * result + ((trxnType == null) ? 0 : trxnType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (clientId == null) {
			if (other.clientId != null)
				return false;
		} else if (!clientId.equals(other.clientId))
			return false;
		if (priority != other.priority)
			return false;
		if (trxnDate == null) {
			if (other.trxnDate != null)
				return false;
		} else if (!trxnDate.equals(other.trxnDate))
			return false;
		if (trxnType == null) {
			if (other.trxnType != null)
				return false;
		} else if (!trxnType.equals(other.trxnType))
			return false;
		return true;
	}
	
	
	public static class TransactionComparator implements Comparator<Transaction> { 
		  
		public int compare(Transaction txn1, Transaction txn2) { 

			int clientIdCompare = txn1.getClientId().compareTo(txn2.getClientId()); 
			int trxnTypeCompare = txn1.getTrxnType().compareTo(txn2.getTrxnType()); 
			int trxnDateCompare = txn1.getTrxnDate().compareTo(txn2.getTrxnDate());
			int priorityCompare = Boolean.valueOf(txn1.isPriority()).compareTo(Boolean.valueOf(txn2.isPriority()));	
			
			if (clientIdCompare == 0) { 
				if(trxnTypeCompare == 0) {
					if(trxnDateCompare == 0) {
							return ((priorityCompare == 0) ? trxnDateCompare : priorityCompare);
					}else {
						return trxnDateCompare;	
					}
				}else {
					return trxnTypeCompare;
				}
			} else { 
				return clientIdCompare; 
			} 
			
		} 
	}

}


