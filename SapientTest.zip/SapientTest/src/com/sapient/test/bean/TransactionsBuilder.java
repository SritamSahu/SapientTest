package com.sapient.test.bean;

import java.util.List;

public interface TransactionsBuilder {
	
	List<Transaction> getTransactions(String inputFilePath);
	
}
