package com.sapient.test.bean;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TransactionsBuilderExcel implements TransactionsBuilder {
	
	@Override
	public List<Transaction> getTransactions(String inputFilePath) {
		 List<Transaction> txnList = new ArrayList<>();
	        FileInputStream fis = null;
	        try {
	            fis = new FileInputStream(inputFilePath);
	 
	            Workbook workbook = new XSSFWorkbook(fis);
	 
	            int numberOfSheets = workbook.getNumberOfSheets();
	 
	            for (int i = 0; i < numberOfSheets; i++) {
	                Sheet sheet = workbook.getSheetAt(i);
	                Iterator rowIterator = sheet.iterator();
	 
	                while (rowIterator.hasNext()) {
	 
	                	Transaction txn = new Transaction();
	                    Row row = (Row) rowIterator.next();
	                    if(row.getRowNum()==0) {
	                    	row = (Row) rowIterator.next();
	                    }
	                    
	                    Iterator cellIterator = row.cellIterator();
	 
	                    while (cellIterator.hasNext()) {
	 
	                        Cell cell = (Cell) cellIterator.next();
	                        if(cell.getColumnIndex() == 0){
	                        	txn.setExtTransId(cell.getStringCellValue());
	                        }else if(cell.getColumnIndex() == 1){
	                        	txn.setClientId(cell.getStringCellValue());
	                        }else if(cell.getColumnIndex() == 2){
	                        	txn.setSecurityId(cell.getStringCellValue());
	                        }else if(cell.getColumnIndex() == 3){
	                        	txn.setTrxnType(cell.getStringCellValue());
	                        }else if(cell.getColumnIndex() == 4){
	                        	txn.setTrxnDate(cell.getDateCellValue());
	                        }else if(cell.getColumnIndex() == 5){
	                        	txn.setMktValue(cell.getNumericCellValue());
	                        }else {
	                        	if(cell.getStringCellValue().equalsIgnoreCase("Y"))
	                        		txn.setPriority(Boolean.TRUE);
	                        	else
	                        		txn.setPriority(Boolean.FALSE);
	                        }
	                        
	                    }

	                    txnList.add(txn);
	                }
	            }
	 
	            fis.close();
	 
	        } catch (FileNotFoundException e) {
	            e.printStackTrace();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
	        return txnList;
	}

}
