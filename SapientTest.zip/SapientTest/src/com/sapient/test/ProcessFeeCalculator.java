package com.sapient.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sapient.test.bean.Transaction;
import com.sapient.test.bean.TransactionsBuilder;
import com.sapient.test.bean.TransactionsBuilderExcel;
import com.sapient.test.business.ReportCreation;
import com.sapient.test.business.ReportCreationImpl;

public class ProcessFeeCalculator {

	public static void main(String[] args) {
		
		 TransactionsBuilder tb = new TransactionsBuilderExcel();
		
		 List<Transaction> txnList =  tb.getTransactions("InputDataFile/SampleData.xlsx");
		 
		 calculateNormalProcessFee(txnList);
		 
		 calculateIntraDayProcessFee(txnList);
		 
		 ReportCreation reporter = new ReportCreationImpl(); 
		 
		 reporter.createReport(txnList , "OutputReportFiles/SampleReport.xlsx");
	}
	
	private static void calculateNormalProcessFee(List<Transaction> txnList) {
		for(Transaction tx : txnList) {
			if(tx.isPriority()) {
				tx.setProcessingFee(500);
			}else {
				if(tx.getTrxnType()=="SELL" || tx.getTrxnType()=="WITHDRAW") {
					tx.setProcessingFee(100);
				}else {
					tx.setProcessingFee(50);
				}
			}
		}
	}
	
	private static void calculateIntraDayProcessFee(List<Transaction> txnList) {

		Map<String,List<Integer>>  processingFeeM = new HashMap<>();

		for(int i=0; i<txnList.size();i++) {
			Transaction tx = txnList.get(i);
			String key = tx.getSecurityId()+tx.getClientId()+tx.getTrxnDate();
			if(processingFeeM.containsKey(key)) {
				List<Integer> d = processingFeeM.get(key);
				if(tx.getTrxnType().equalsIgnoreCase("SELL")) {
					for(int x : d) {
						Transaction temptx = txnList.get(x);
						if(temptx.getTrxnType().equalsIgnoreCase("BUY")) {
							temptx.setProcessingFee(temptx.getProcessingFee()+10);
							temptx.setIntra(Boolean.TRUE);
							tx.setProcessingFee(tx.getProcessingFee()+10);
							tx.setIntra(Boolean.TRUE);
						}
					}
				}else if(tx.getTrxnType().equalsIgnoreCase("BUY")) {
					for(int x : d) {
						Transaction temptx = txnList.get(x);
						if(temptx.getTrxnType().equalsIgnoreCase("SELL")) {
							temptx.setProcessingFee(temptx.getProcessingFee()+10);
							temptx.setIntra(Boolean.TRUE);
							tx.setProcessingFee(tx.getProcessingFee()+10);
							tx.setIntra(Boolean.TRUE);
						}
					}
				}
				d.add(i);
				processingFeeM.put(key, d);
			}else {
				List<Integer> d = new ArrayList<>();
				d.add(i);
				processingFeeM.put(key, d);
			}
			
		}
	}
	
	
}
